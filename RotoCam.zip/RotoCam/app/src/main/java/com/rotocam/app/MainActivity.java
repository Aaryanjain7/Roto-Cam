package com.rotocam.app;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ImageReader;
import android.media.Image;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "RotoCam";
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final float STABLE_THRESHOLD = 0.5f;      // m/s² — how still phone must be
    private static final float STABLE_DURATION_MS = 1500f;   // ms phone must stay still
    private static final int CAPTURE_INTERVAL_DEG = 90;      // degrees between shots
    private static final float ROTATION_DEAD_ZONE = 5f;      // degrees — ignore tiny jitter

    // Sensor
    private SensorManager sensorManager;
    private Sensor accelerometer, gyroscope;
    private float[] gravity = new float[3];
    private float currentAzimuth = 0f;      // yaw in degrees [0..360)
    private float baseAzimuth = -1f;        // azimuth when session started
    private float lastCaptureAzimuth = -1f; // azimuth of last capture
    private long stableStartTime = -1;
    private boolean isPhoneStable = false;

    // Camera
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private CaptureRequest.Builder previewRequestBuilder;
    private ImageReader imageReader;
    private TextureView textureView;
    private Size previewSize;
    private String cameraId;

    // State
    private boolean sessionActive = false;
    private int photosTaken = 0;
    private int nextTargetStep = 0;   // 0→90→180→270→360(==0)
    private Vibrator vibrator;

    // UI
    private Button btnStart, btnStop;
    private TextView tvStatus, tvAngle, tvPhotos, tvStable;
    private ImageView ivCompass;

    // Handler for camera background thread
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textureView = findViewById(R.id.textureView);
        btnStart    = findViewById(R.id.btnStart);
        btnStop     = findViewById(R.id.btnStop);
        tvStatus    = findViewById(R.id.tvStatus);
        tvAngle     = findViewById(R.id.tvAngle);
        tvPhotos    = findViewById(R.id.tvPhotos);
        tvStable    = findViewById(R.id.tvStable);
        ivCompass   = findViewById(R.id.ivCompass);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope     = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        vibrator      = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        btnStart.setOnClickListener(v -> startSession());
        btnStop.setOnClickListener(v -> stopSession());

        checkPermissions();
    }

    // ─── Permissions ─────────────────────────────────────────────────────────

    private void checkPermissions() {
        String[] perms = {
            Manifest.permission.CAMERA,
            Manifest.permission.VIBRATE,
        };
        List<String> needed = new ArrayList<>();
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                needed.add(p);
        }
        if (!needed.isEmpty())
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        else
            setupCamera();
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        boolean allGranted = true;
        for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) { allGranted = false; break; }
        if (allGranted) setupCamera();
        else Toast.makeText(this, "Camera & Vibrate permissions required", Toast.LENGTH_LONG).show();
    }

    // ─── Camera Setup ─────────────────────────────────────────────────────────

    private void setupCamera() {
        startBackgroundThread();
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics chars = manager.getCameraCharacteristics(id);
                Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id;
                    StreamConfigurationMap map = chars.get(
                        CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                    if (map != null) {
                        Size[] sizes = map.getOutputSizes(ImageReader.class);
                        previewSize = sizes[0]; // largest available
                    }
                    break;
                }
            }
            openCamera();
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera setup error", e);
        }
    }

    private void openCamera() {
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) return;

            imageReader = ImageReader.newInstance(
                previewSize.getWidth(), previewSize.getHeight(),
                android.graphics.ImageFormat.JPEG, 2);
            imageReader.setOnImageAvailableListener(reader -> {
                try (Image image = reader.acquireLatestImage()) {
                    if (image != null) saveImage(image);
                }
            }, backgroundHandler);

            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(@NonNull CameraDevice camera) {
                    cameraDevice = camera;
                    createPreviewSession();
                }
                @Override public void onDisconnected(@NonNull CameraDevice camera) { camera.close(); }
                @Override public void onError(@NonNull CameraDevice camera, int error) {
                    camera.close(); cameraDevice = null;
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Open camera error", e);
        }
    }

    private void createPreviewSession() {
        try {
            Surface previewSurface = new Surface(textureView.getSurfaceTexture());
            Surface captureSurface = imageReader.getSurface();

            previewRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            previewRequestBuilder.addTarget(previewSurface);

            cameraDevice.createCaptureSession(Arrays.asList(previewSurface, captureSurface),
                new CameraCaptureSession.StateCallback() {
                    @Override public void onConfigured(@NonNull CameraCaptureSession session) {
                        captureSession = session;
                        try {
                            previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                            captureSession.setRepeatingRequest(
                                previewRequestBuilder.build(), null, backgroundHandler);
                        } catch (CameraAccessException e) { Log.e(TAG, "Preview error", e); }
                    }
                    @Override public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                        Toast.makeText(MainActivity.this, "Camera config failed", Toast.LENGTH_SHORT).show();
                    }
                }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Session error", e);
        }
    }

    // ─── Session Control ──────────────────────────────────────────────────────

    private void startSession() {
        if (sessionActive) return;
        sessionActive  = true;
        photosTaken    = 0;
        nextTargetStep = 0;
        baseAzimuth    = -1f; // will be set on first stable position
        lastCaptureAzimuth = -1f;

        btnStart.setEnabled(false);
        btnStop.setEnabled(true);
        tvStatus.setText("Hold phone STILL to begin...");

        sensorManager.registerListener(this, accelerometer,
            SensorManager.SENSOR_DELAY_UI);
        sensorManager.registerListener(this, gyroscope,
            SensorManager.SENSOR_DELAY_GAME);
    }

    private void stopSession() {
        sessionActive = false;
        sensorManager.unregisterListener(this);
        btnStart.setEnabled(true);
        btnStop.setEnabled(false);
        tvStatus.setText("Session stopped. Photos: " + photosTaken);
        tvStable.setText("");
    }

    // ─── Sensor Callbacks ─────────────────────────────────────────────────────

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!sessionActive) return;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // Low-pass filter for gravity
            final float ALPHA = 0.8f;
            gravity[0] = ALPHA * gravity[0] + (1 - ALPHA) * event.values[0];
            gravity[1] = ALPHA * gravity[1] + (1 - ALPHA) * event.values[1];
            gravity[2] = ALPHA * gravity[2] + (1 - ALPHA) * event.values[2];

            // Linear acceleration = raw - gravity
            float ax = event.values[0] - gravity[0];
            float ay = event.values[1] - gravity[1];
            float az = event.values[2] - gravity[2];
            float motion = (float) Math.sqrt(ax*ax + ay*ay + az*az);

            boolean nowStable = motion < STABLE_THRESHOLD;
            if (nowStable) {
                if (stableStartTime < 0) stableStartTime = System.currentTimeMillis();
                long elapsed = System.currentTimeMillis() - stableStartTime;
                if (!isPhoneStable && elapsed >= STABLE_DURATION_MS) {
                    isPhoneStable = true;
                    onPhoneStabilized();
                }
            } else {
                stableStartTime = -1;
                isPhoneStable   = false;
                runOnUiThread(() -> tvStable.setText("⟳  Moving…"));
            }
        }

        if (event.sensor.getType() == Sensor.TYPE_GAME_ROTATION_VECTOR) {
            float[] rotMatrix = new float[9];
            float[] orientation = new float[3];
            SensorManager.getRotationMatrixFromVector(rotMatrix, event.values);
            SensorManager.getOrientation(rotMatrix, orientation);

            // Convert radians → degrees, normalise to [0..360)
            float azDeg = (float) Math.toDegrees(orientation[0]);
            if (azDeg < 0) azDeg += 360f;
            currentAzimuth = azDeg;

            final float displayAz = azDeg;
            runOnUiThread(() -> {
                tvAngle.setText(String.format(Locale.getDefault(), "Azimuth: %.1f°", displayAz));
                ivCompass.setRotation(-displayAz);
            });

            if (isPhoneStable && baseAzimuth >= 0) checkRotationCapture();
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    // ─── Stable / Capture Logic ───────────────────────────────────────────────

    private void onPhoneStabilized() {
        vibrateShort();
        if (baseAzimuth < 0) {
            // First stable position — set origin
            baseAzimuth        = currentAzimuth;
            lastCaptureAzimuth = currentAzimuth;
            nextTargetStep     = CAPTURE_INTERVAL_DEG; // first target
            runOnUiThread(() -> tvStatus.setText(
                "Origin set! Now ROTATE phone slowly 360°"));
            capturePhoto(); // capture at 0°
        }
        runOnUiThread(() -> tvStable.setText("✔ Stable"));
    }

    private void checkRotationCapture() {
        if (baseAzimuth < 0) return;

        // Angular distance from base, normalised [0..360)
        float delta = currentAzimuth - baseAzimuth;
        if (delta < 0) delta += 360f;

        // Check if we passed the next target (within dead-zone window)
        float target = nextTargetStep % 360;
        float diff   = Math.abs(delta - target);
        if (diff > 180f) diff = 360f - diff; // wrap

        if (diff <= ROTATION_DEAD_ZONE) {
            float lastDiff = Math.abs(currentAzimuth - lastCaptureAzimuth);
            if (lastDiff > 180f) lastDiff = 360f - lastDiff;
            if (lastDiff > (CAPTURE_INTERVAL_DEG / 2f)) {
                lastCaptureAzimuth = currentAzimuth;
                nextTargetStep += CAPTURE_INTERVAL_DEG;
                capturePhoto();

                if (photosTaken >= 4) {
                    runOnUiThread(() -> {
                        tvStatus.setText("✅ 360° complete! " + photosTaken + " photos saved.");
                        stopSession();
                    });
                    vibrateLong();
                }
            }
        }
    }

    private void capturePhoto() {
        if (captureSession == null || cameraDevice == null) return;
        try {
            CaptureRequest.Builder captureBuilder =
                cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(imageReader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            int rotation = getWindowManager().getDefaultDisplay().getRotation();
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION,
                getJpegOrientation(cameraId, rotation));

            captureSession.capture(captureBuilder.build(),
                new CameraCaptureSession.CaptureCallback() {
                    @Override public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                            @NonNull CaptureRequest request, @NonNull TotalCaptureResult result) {
                        photosTaken++;
                        vibrateShort();
                        runOnUiThread(() -> {
                            tvPhotos.setText("📷 Photos: " + photosTaken + " / 4");
                            tvStatus.setText("Photo " + photosTaken + " captured at "
                                + String.format(Locale.getDefault(), "%.0f°", currentAzimuth - baseAzimuth < 0
                                    ? currentAzimuth - baseAzimuth + 360 : currentAzimuth - baseAzimuth));
                        });
                    }
                }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Capture error", e);
        }
    }

    private void saveImage(Image image) {
        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
            .format(new Date());
        String fileName = "RotoCam_" + timestamp + ".jpg";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RotoCam");

        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri != null) {
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os != null) os.write(bytes);
                Log.d(TAG, "Saved: " + fileName);
            } catch (IOException e) {
                Log.e(TAG, "Save error", e);
            }
        }
    }

    // ─── Vibration ────────────────────────────────────────────────────────────

    private void vibrateShort() {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
        else vibrator.vibrate(80);
    }

    private void vibrateLong() {
        if (vibrator == null) return;
        long[] pattern = {0, 100, 80, 200, 80, 400};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
        else vibrator.vibrate(pattern, -1);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private int getJpegOrientation(String cameraId, int deviceRotation) {
        int[] surfaceOrientations = {0, 90, 180, 270};
        int deviceDegrees = surfaceOrientations[deviceRotation];
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            CameraCharacteristics c = manager.getCameraCharacteristics(cameraId);
            Integer sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (sensorOrientation == null) sensorOrientation = 0;
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            boolean isFront = facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT;
            if (isFront) return (sensorOrientation + deviceDegrees) % 360;
            else         return (sensorOrientation - deviceDegrees + 360) % 360;
        } catch (CameraAccessException e) { return 0; }
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try { backgroundThread.join(); backgroundThread = null; backgroundHandler = null; }
            catch (InterruptedException e) { Log.e(TAG, "BG thread interrupted", e); }
        }
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        startBackgroundThread();
        if (cameraDevice == null) setupCamera();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopSession();
        if (captureSession != null) { captureSession.close(); captureSession = null; }
        if (cameraDevice != null)   { cameraDevice.close();   cameraDevice   = null; }
        if (imageReader != null)    { imageReader.close();    imageReader    = null; }
        stopBackgroundThread();
    }
}
