# RotoCam 📷

An Android app that uses your phone's sensors to automatically capture photos every 90° as you rotate the phone, creating a complete 360° set of 4 photos.

---

## How It Works

| Step | What Happens |
|------|-------------|
| 1 | Open app, press **START** |
| 2 | Hold phone **still** for 1.5 seconds — phone **vibrates** to confirm stable position |
| 3 | Photo 1 is captured at 0° |
| 4 | Slowly **rotate** the phone on the spot (yaw/horizontal) |
| 5 | Every 90° the phone **vibrates** and captures a photo |
| 6 | After 4 photos (full 360°) the phone gives a **triple vibration** and session ends |

Photos are saved to **DCIM/RotoCam/** in your gallery.

---

## Project Setup in Android Studio

1. Open **Android Studio** → `File → Open` → select the `RotoCam` folder
2. Let Gradle sync finish
3. Connect your Android phone (USB debugging on) or use an emulator with camera support
4. Press **Run ▶**

### Minimum Requirements
- Android **6.0 (API 23)** or higher
- Physical device with **gyroscope + accelerometer** (recommended — emulators lack real sensor data)
- Camera permission + Vibrate permission (prompted on first launch)

---

## Key Settings (easy to tweak in `MainActivity.java`)

```java
private static final float STABLE_THRESHOLD    = 0.5f;   // m/s² — lower = stricter stillness
private static final float STABLE_DURATION_MS  = 1500f;  // ms to hold still before trigger
private static final int   CAPTURE_INTERVAL_DEG = 90;    // degrees between shots
private static final float ROTATION_DEAD_ZONE  = 5f;     // ±degrees tolerance at target angle
```

---

## Permissions Used

| Permission | Reason |
|-----------|--------|
| `CAMERA` | Capture photos |
| `VIBRATE` | Haptic feedback on stable/capture |
| `WRITE_EXTERNAL_STORAGE` | Save photos (Android ≤ 9 only; MediaStore used for Android 10+) |

---

## File Structure

```
RotoCam/
├── app/src/main/
│   ├── java/com/rotocam/app/
│   │   └── MainActivity.java        ← all logic here
│   ├── res/
│   │   ├── layout/activity_main.xml ← UI layout
│   │   ├── drawable/ic_compass.xml  ← rotating compass overlay
│   │   └── values/
│   │       ├── strings.xml
│   │       └── themes.xml
│   └── AndroidManifest.xml
├── app/build.gradle
├── build.gradle
└── settings.gradle
```
